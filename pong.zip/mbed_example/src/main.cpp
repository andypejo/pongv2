#include <mbed.h>
#include <MMA7455.h>
#include <LM75B.h>
#include <display.h>

//Declare output object for LED1
DigitalOut led1(LED1);

// Initialise Joystick   
typedef enum {JLT = 0, JRT, JUP, JDN, JCR} btnId_t;
static DigitalIn jsBtns[] = {P5_0, P5_4, P5_2, P5_1, P5_3}; // LFT, RGHT, UP, DWN, CTR
bool jsPrsdAndRlsd(btnId_t b);

//Input object for the potentiometer
AnalogIn pot(p15);
float potVal = 0.0;
  
//Object to manage the accelerometer
MMA7455 acc(P0_27, P0_28);
bool accInit(MMA7455& acc); //prototype of init routine
int32_t accVal[3];

//Object to manage temperature sensor
LM75B lm75b(P0_27, P0_28, LM75B::ADDRESS_1);
float tempVal = 0.0;

Display *screen = Display::theDisplay();
    //This is how you call a static method of class Display
    //Returns a pointer to an object that manages the display screen 

//Timer interrupt and handler
void timerHandler(); //prototype of handler function
int tickCt = 0;

//Drawing coordinates
int x = 240, y = 262, dx = 0, dy = 0, bx = 0, by = 0;

int randomrange(int from, int to){
    int range = to-from;
    return from  + rand()%(range+1);
	}

int currentBalls = 0;
int score = 0;	
int gameStart = 0;
int scoreIncrement = 0;
int scoreAdd = 1;
int continueGame = 0;
	
int main() {
  // Initialise the display
  screen->fillScreen(BLACK);
  screen->setTextColor(WHITE, BLACK);

  //Initialise ticker and install interrupt handler
  Ticker ticktock;
  ticktock.attach(&timerHandler, 1);
  
  screen->drawRect(0, 1, 480, 272, WHITE);
	screen->drawRect(0, 1, 480, 30, WHITE);

  while (true) {
    //potVal = pot.read();
    //tempVal = lm75b.temp();
    //acc.read(accVal[0], accVal[1], accVal[2]);
	
		int randNumberX; //Balls X axis 'Says how fast it goes left + right'
		int randNumberY; //Balls Y axis 'Says how fast it goes up + down'
		int ballStart;
		int ballDirectionLeft; //Bounces ball left
		int ballDirectionRight; // Bounces ball right
		int ballDirectionUp; // Bounces ball Up
		int ballDirectionDown; // Bounces ball down 
			
	/*************************************************************************************/
	/**************************DISPLAYS SCORE AND LIVES***********************************/		
	/*************************************************************************************/	
		screen->setCursor(2,2);
    screen->printf("Balls Left = %d" , currentBalls);
		
		screen->setCursor(300,2);
    screen->printf("Score = %d" , score);
		
	/*************************************************************************************/
	/*************************************************************************************/		
	/*************************************************************************************/	
		
		
if (jsPrsdAndRlsd(JCR) ) { // STARTS/RESTARTS GAME 
		if (currentBalls >= 1 && continueGame == 0){
				score = 0;
				gameStart = 0;
			  screen->setCursor(100,136);
			  screen->printf("RESTARTING!!");
				wait(1);
				screen->fillRect(1, 31, 478, 240, BLACK);
				screen->fillRect(x, y, 40, 4, BLACK);
				x = 240;
				currentBalls = 5;
				gameStart = 1;
				ballStart = 1;
		}
		
		if (currentBalls >= 1 && continueGame == 1){
				continueGame = 0;
				gameStart = 1;
				screen->fillRect(1, 31, 478, 240, BLACK);
				screen->fillRect(x, y, 40, 4, BLACK);
				x = 240;
				ballStart = 1;
		}
		
		if (currentBalls <= 0) {
				score = 0;
				currentBalls = 5;
				gameStart = 1;
				ballStart = 1;
				screen->fillRect(1, 31, 478, 240, BLACK);
				screen->fillRect(x, y, 40, 4, BLACK);
				x = 240;
		}
}



		if (gameStart == 1) {	//RUNS GAME  
			
				if (ballStart == 1){
					randNumberX = rand() % (380 + 1 -0) + 50;
					randNumberY = rand() % (50 + 1 -0) + 40;	
					bx = 1;
					by = 1;
					ballStart--;
				}
	
			/*************************************************************************************/
			/*******************************BALL COLLISION DETECTION******************************/		
			/*************************************************************************************/	
				if (randNumberX > 470 ){ //Checks for bounce on right wall
					ballDirectionLeft = 1;
					ballDirectionRight = 0;
				}
				
				if (randNumberX < 10 ){ //Checks for bounce on left wall
					ballDirectionRight = 1;
					ballDirectionLeft = 0;
				}
				
				if (randNumberX > x -1 && randNumberX < x + 41 ){ //Checks for bounce on bat 
					if (randNumberY > y - 5){
							ballDirectionUp = 1;
							ballDirectionDown = 0;
					}
				}
				
				if (randNumberY > 277){ //Checks if ball off screen
					randNumberX = rand() % (380 + 1 -0) + 50;
					randNumberY = rand() % (50 + 1 -0) + 40;	
					bx = 2;
					scoreAdd = 1;
					currentBalls--;
					continueGame = 1;
					gameStart = 0;
					screen->fillRect(1, 31, 478, 240, BLACK);
					screen->fillRect(x, y, 40, 4, BLACK);
					x = 240;
				}
				

			/*************************************************************************************/
			/*************************************************************************************/		
			/*************************************************************************************/	
				
				
			/*************************************************************************************/
			/****************************BALL BOUNCE DIRECTION************************************/		
			/*************************************************************************************/	
					if (ballDirectionLeft == 1){	
							bx = -1;
							by = 1;
					}
					
					if (ballDirectionRight == 1){
							bx = 1;
							by = 1;
					}
					if (ballDirectionUp == 1){
							by = -1;
					}
					if (ballDirectionDown == 1){
							by = 1;
					}
			/*************************************************************************************/
			/*************************************************************************************/		
			/*************************************************************************************/	
					
					
			/*************************************************************************************/
			/*************************GAME SCORE AND GAME END*************************************/		
			/*************************************************************************************/	
					if (currentBalls == 0){
						screen->fillRect(1, 31, 478, 240, BLACK);
						screen->setCursor(100,136);
						screen->printf("GAME OVER!! PRESS JOYSTICK CENTER TO RESTART");
					  continueGame = 0;
						gameStart = 0;
					}
					
					screen->setCursor(100,60);
					screen->printf("Increment: %d ,  score add: %d, Y axis: %d",  scoreIncrement, scoreAdd,randNumberY);
					
			    if (randNumberY < 40){ //checks if ball hits top
						ballDirectionUp = 0;
						ballDirectionDown = 1;
						score = score + scoreAdd;
						scoreIncrement = scoreIncrement + 1;
				  }	

					if (scoreIncrement == 15){
						scoreAdd = scoreAdd + 1;
						scoreIncrement = 0;
					}					
			/*************************************************************************************/
			/*************************************************************************************/		
			/*************************************************************************************/		
					
			/*************************************************************************************/
			/*************************DRAW OBJECTS ON SCREEN AND BAT CONTROLS**********************/		
			/*************************************************************************************/	
				screen->fillCircle(randNumberX, randNumberY, 5, BLACK);
			  randNumberX += bx;
			  randNumberY += by;
			  screen->fillCircle(randNumberX, randNumberY, 5, BLUE);			
					
				screen->fillRect(x, y, 40, 4, BLACK);
				x += dx;
				y += dy;
				screen->fillRect(x, y, 40, 4, WHITE);
					
				if (jsPrsdAndRlsd(JLT)) { 
					dx = 2; dy = 0;                 
				} else if (jsPrsdAndRlsd(JRT)) {
					dx = -2; dy = 0;
				}
				
				if (x > 440 ){
					dx = 0;
					x = 439;
				}
				
				if (x < 0 ){
					dx = 0;
					x = 1;
				}
			/*************************************************************************************/
			/*************************************************************************************/		
			/*************************************************************************************/				
		    wait(0.005); //5 milliseconds
  }
}
}

bool accInit(MMA7455& acc) {
  bool result = true;
  if (!acc.setMode(MMA7455::ModeMeasurement)) {
    // screen->printf("Unable to set mode for MMA7455!\n");
    result = false;
  }
  if (!acc.calibrate()) {
    // screen->printf("Failed to calibrate MMA7455!\n");
    result = false;
  }
  // screen->printf("MMA7455 initialised\n");
  return result;
}

//Definition of timer interrupt handler
void timerHandler() {
  tickCt++;
  led1 = !led1; //every tick, toggle led1
}

/* Definition of Joystick press capture function
 * b is one of JLEFT, JRIGHT, JUP, JDOWN - from enum, 0, 1, 2, 3
 * Returns true if this Joystick pressed then released, false otherwise.
 *
 * If the value of the button's pin is 0 then the button is being pressed,
 * just remember this in savedState.
 * If the value of the button's pin is 1 then the button is released, so
 * if the savedState of the button is 0, then the result is true, otherwise
 * the result is false. */
bool jsPrsdAndRlsd(btnId_t b) {
	bool result = false;
	uint32_t state;
	static uint32_t savedState[4] = {1,1,1,1};
        //initially all 1s: nothing pressed
	state = jsBtns[b].read();
  if ((savedState[b] == 0) && (state == 1)) {
		result = true;
	}
	savedState[b] = state;
	return result;
}
